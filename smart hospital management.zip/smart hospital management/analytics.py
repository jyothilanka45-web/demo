from datetime import datetime, timedelta
from sqlalchemy import func
from models import db, User, PatientProfile, DoctorProfile, Appointment, Queue, Bed, MedicalRecord

def get_dashboard_analytics():
    """
    Retrieves all dynamic hospital statistics to compile JSON statistics.
    """
    stats = {}

    # 1. Patients per day (last 7 days)
    today = datetime.utcnow().date()
    daily_patients = []
    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        count = db.session.query(Appointment).filter(
            func.date(Appointment.created_at) == day
        ).count()
        daily_patients.append({
            "date": day.strftime('%Y-%m-%d'),
            "day": day.strftime('%a'),
            "count": count
        })
    stats["daily_patients"] = daily_patients

    # 2. Disease Urgency Distribution (Emergency stats)
    critical_count = db.session.query(Appointment).filter_by(triage_urgency='Critical').count()
    moderate_count = db.session.query(Appointment).filter_by(triage_urgency='Moderate').count()
    normal_count = db.session.query(Appointment).filter_by(triage_urgency='Normal').count()
    stats["urgency_distribution"] = [
        {"urgency": "Critical", "count": critical_count},
        {"urgency": "Moderate", "count": moderate_count},
        {"urgency": "Normal", "count": normal_count}
    ]

    # 3. Doctor Workload (Total appointments assigned per doctor)
    doctor_workload = []
    doctors = db.session.query(DoctorProfile).all()
    for doc in doctors:
        count = db.session.query(Appointment).filter_by(doctor_id=doc.id, status='Scheduled').count()
        doctor_workload.append({
            "name": doc.user.name,
            "department": doc.department,
            "pending_appointments": count
        })
    stats["doctor_workload"] = doctor_workload

    # 4. Average Waiting Time per Department (in minutes)
    departments = ["General Medicine", "Cardiology", "Pediatrics", "Orthopedics"]
    dept_waiting_time = []
    for dept in departments:
        avg_wait = db.session.query(func.avg(Queue.estimated_wait_time)).filter_by(
            department=dept, status='Waiting'
        ).scalar()
        dept_waiting_time.append({
            "department": dept,
            "avg_wait": int(avg_wait) if avg_wait else 0
        })
    stats["department_waiting_time"] = dept_waiting_time

    # 5. Bed Occupancy Stats
    total_beds = db.session.query(Bed).count()
    occupied_beds = db.session.query(Bed).filter_by(status='Occupied').count()
    icu_total = db.session.query(Bed).filter_by(ward_type='ICU').count()
    icu_occupied = db.session.query(Bed).filter_by(ward_type='ICU', status='Occupied').count()
    
    stats["beds_summary"] = {
        "total": total_beds,
        "occupied": occupied_beds,
        "available": total_beds - occupied_beds,
        "icu_total": icu_total,
        "icu_occupied": icu_occupied,
        "icu_available": icu_total - icu_occupied
    }

    return stats
