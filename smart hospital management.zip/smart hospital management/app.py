import os
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from sqlalchemy import func
from config import Config
from models import db, User, PatientProfile, DoctorProfile, Appointment, Queue, MedicalRecord, Bed, Resource, StaffTask, Notification
from triage_engine import analyze_symptoms, calculate_estimated_wait, predict_disease_risks, predict_readmission_risk, summarize_medical_record, predict_hospital_demand
from chatbot import get_chatbot_response
from analytics import get_dashboard_analytics

app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
db.init_app(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- Database Seeding Helper ---
def seed_database():
    """
    Seeds default administrative, clinical staff, beds and assets 
    only if the database is clean.
    """
    # Create tables
    db.create_all()

    # Check if we already have users
    if User.query.first() is not None:
        return

    print("Initial seeding of clean database with roles...")
    
    # 1. Admin/Receptionist
    admin = User(username='admin', email='admin@smarthospital.com', role='admin', name='Admin Receptionist', phone='123-456-7890')
    admin.set_password('admin123')
    db.session.add(admin)

    # 2. Doctors
    doctors_data = [
        {'username': 'dr_heart', 'email': 'dr.heart@smarthospital.com', 'name': 'Dr. Alistair Heart', 'dept': 'Cardiology', 'spec': 'Cardiology - Heart Disease Specialist', 'room': 'Room 101'},
        {'username': 'dr_general', 'email': 'dr.gen@smarthospital.com', 'name': 'Dr. Sarah General', 'dept': 'General Medicine', 'spec': 'General Practice & Infectious Diseases', 'room': 'Room 102'},
        {'username': 'dr_kids', 'email': 'dr.kids@smarthospital.com', 'name': 'Dr. Peter Kids', 'dept': 'Pediatrics', 'spec': 'Pediatrician & Neonatology', 'room': 'Room 103'},
        {'username': 'dr_bones', 'email': 'dr.bones@smarthospital.com', 'name': 'Dr. Robert Bones', 'dept': 'Orthopedics', 'spec': 'Orthopedic Surgeon - Joints & Fractures', 'room': 'Room 104'}
    ]

    for doc in doctors_data:
        u = User(username=doc['username'], email=doc['email'], role='doctor', name=doc['name'], phone='555-010-0200')
        u.set_password('doctor123')
        db.session.add(u)
        db.session.flush() # get user id
        
        dp = DoctorProfile(user_id=u.id, department=doc['dept'], specialization=doc['spec'], room_no=doc['room'])
        db.session.add(dp)

    # 3. Nurse
    nurse = User(username='nurse_jane', email='nurse.jane@smarthospital.com', role='nurse', name='Nurse Jane', phone='555-020-0300')
    nurse.set_password('nurse123')
    db.session.add(nurse)

    # 4. Beds (General & ICU)
    for i in range(1, 11):
        ward = 'ICU' if i <= 3 else 'General'
        status = 'Available'
        bed = Bed(bed_number=f"BED-{ward[0]}{i:02d}", ward_type=ward, status=status)
        db.session.add(bed)

    # 5. Resources (Critical Hospital Supplies)
    resources_data = [
        {'name': 'Ventilator', 'qty': 8, 'loc': 'ICU Ward A'},
        {'name': 'Defibrillator', 'qty': 5, 'loc': 'Emergency Room'},
        {'name': 'ECG Monitor', 'qty': 12, 'loc': 'Cardiac Wing'},
        {'name': 'Oxygen Concentrator', 'qty': 20, 'loc': 'General Ward B'}
    ]
    for res in resources_data:
        r = Resource(name=res['name'], total_qty=res['qty'], available_qty=res['qty'], location=res['loc'])
        db.session.add(r)

    db.session.commit()
    print("Database seeding completed.")


# --- Routes ---

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for(f'dashboard_{current_user.role}'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for(f'dashboard_{current_user.role}'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        role = request.form.get('role')
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            if user.role != role:
                flash('Invalid role selected for this user.', 'danger')
                return render_template('login.html')
            
            login_user(user)
            flash(f'Logged in successfully as {user.name}!', 'success')
            return redirect(url_for(f'dashboard_{user.role}'))
        else:
            flash('Invalid username or password.', 'danger')
            
    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for(f'dashboard_{current_user.role}'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        name = request.form.get('name')
        phone = request.form.get('phone')
        age = request.form.get('age')
        gender = request.form.get('gender')
        blood_group = request.form.get('blood_group')
        medical_history = request.form.get('medical_history')

        # Check existing
        if User.query.filter((User.username == username) | (User.email == email)).first():
            flash('Username or Email already registered.', 'danger')
            return render_template('register.html')

        try:
            # Create user
            user = User(username=username, email=email, role='patient', name=name, phone=phone)
            user.set_password(password)
            db.session.add(user)
            db.session.flush() # get user.id

            # Create patient profile
            patient = PatientProfile(user_id=user.id, age=int(age), gender=gender, blood_group=blood_group, medical_history=medical_history)
            db.session.add(patient)
            
            db.session.commit()
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash(f'Error during registration: {str(e)}', 'danger')

    return render_template('register.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))


# --- Dashboards ---

@app.route('/dashboard/patient')
@login_required
def dashboard_patient():
    if current_user.role != 'patient':
        return redirect(url_for('index'))
    
    patient = current_user.patient_profile
    # Appointments
    appointments = Appointment.query.filter_by(patient_id=patient.id).order_id_desc = Appointment.created_at.desc()
    appointments = Appointment.query.filter_by(patient_id=patient.id).order_by(Appointment.created_at.desc()).all()
    
    # Active Queues
    active_queues = Queue.query.join(Appointment).filter(
        Appointment.patient_id == patient.id,
        Queue.status.in_(['Waiting', 'Serving'])
    ).all()

    # AI Health Risk Predictions
    risks = predict_disease_risks(patient.age, patient.gender, patient.medical_history)

    # Medical Records
    records = MedicalRecord.query.filter_by(patient_id=patient.id).order_by(MedicalRecord.visit_date.desc()).all()

    # Notifications
    notifications = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).limit(5).all()

    # Get doctors for booking form
    doctors = DoctorProfile.query.all()

    return render_template('dashboard_patient.html', 
                           patient=patient, 
                           appointments=appointments, 
                           active_queues=active_queues, 
                           risks=risks,
                           records=records,
                           notifications=notifications,
                           doctors=doctors)


@app.route('/dashboard/doctor', methods=['GET', 'POST'])
@login_required
def dashboard_doctor():
    if current_user.role != 'doctor':
        return redirect(url_for('index'))
        
    doctor = current_user.doctor_profile

    # Toggle doctor availability
    if request.method == 'POST' and 'toggle_availability' in request.form:
        new_status = request.form.get('availability_status')
        if new_status in ['Available', 'Busy', 'Off-Duty']:
            doctor.availability_status = new_status
            db.session.commit()
            flash(f'Availability status updated to {new_status}.', 'success')
            return redirect(url_for('dashboard_doctor'))

    # Retrieve current active patient/serving token
    active_serving = Queue.query.join(Appointment).filter(
        Appointment.doctor_id == doctor.id,
        Queue.status == 'Serving'
    ).first()

    # Retrieve patient queue - prioritised by score (Critical first, then Moderate, then Normal, then creation order)
    # This executes the AI-driven Priority Queue Routing.
    queue_entries = Queue.query.join(Appointment).filter(
        Appointment.doctor_id == doctor.id,
        Queue.status == 'Waiting'
    ).order_by(Queue.priority_score.desc(), Queue.created_at.asc()).all()

    # Past Medical Records written by this doctor
    past_records = MedicalRecord.query.filter_by(doctor_id=doctor.id).order_by(MedicalRecord.visit_date.desc()).all()

    return render_template('dashboard_doctor.html', 
                           doctor=doctor, 
                           active_serving=active_serving, 
                           queue_entries=queue_entries, 
                           past_records=past_records)


@app.route('/dashboard/nurse')
@login_required
def dashboard_nurse():
    if current_user.role != 'nurse':
        return redirect(url_for('index'))
        
    beds = Bed.query.all()
    resources = Resource.query.all()
    tasks = StaffTask.query.filter_by(assigned_to_user_id=current_user.id).order_by(StaffTask.created_at.desc()).all()
    patients = PatientProfile.query.all() # For bed allocation dropdown

    return render_template('dashboard_nurse.html', beds=beds, resources=resources, tasks=tasks, patients=patients)


@app.route('/dashboard/admin')
@login_required
def dashboard_admin():
    if current_user.role != 'admin':
        return redirect(url_for('index'))
        
    # Stats counts
    total_patients = PatientProfile.query.count()
    total_doctors = DoctorProfile.query.count()
    active_appointments = Appointment.query.filter_by(status='Scheduled').count()
    active_queues = Queue.query.filter(Queue.status.in_(['Waiting', 'Serving'])).all()
    
    # Staff Tasks
    nurses = User.query.filter_by(role='nurse').all()
    all_tasks = StaffTask.query.order_by(StaffTask.created_at.desc()).all()

    # Beds & Resources
    beds = Bed.query.all()
    resources = Resource.query.all()

    # Generate Chart Analytics JSON
    analytics_data = get_dashboard_analytics()

    # AI Hospital Demand Prediction
    # Grab daily counts for demand calculations
    appt_counts = {}
    today = datetime.utcnow().date()
    for i in range(7):
        day = today - timedelta(days=i)
        count = db.session.query(Appointment).filter(func.date(Appointment.created_at) == day).count()
        appt_counts[day.strftime('%Y-%m-%d')] = count
    
    demand_forecast = predict_hospital_demand(appt_counts)

    return render_template('dashboard_admin.html',
                           total_patients=total_patients,
                           total_doctors=total_doctors,
                           active_appointments=active_appointments,
                           active_queues=active_queues,
                           nurses=nurses,
                           all_tasks=all_tasks,
                           beds=beds,
                           resources=resources,
                           analytics=analytics_data,
                           demand_forecast=demand_forecast)


# --- Core Actions & API Endpoints ---

@app.route('/book-appointment', methods=['POST'])
@login_required
def book_appointment():
    if current_user.role != 'patient':
        return redirect(url_for('index'))
        
    patient = current_user.patient_profile
    doctor_id = request.form.get('doctor_id')
    appt_date_str = request.form.get('appointment_date')
    slot_time = request.form.get('slot_time')
    symptoms = request.form.get('symptoms')

    if not doctor_id or not appt_date_str or not slot_time or not symptoms:
        flash("All fields are required to schedule an appointment.", "danger")
        return redirect(url_for('dashboard_patient'))

    try:
        appt_date = datetime.strptime(appt_date_str, '%Y-%m-%d').date()
    except ValueError:
        flash("Invalid date format.", "danger")
        return redirect(url_for('dashboard_patient'))

    # Prevent Overbooking: Max 3 slots per time block per doctor
    overlap_count = Appointment.query.filter_by(
        doctor_id=doctor_id,
        appointment_date=appt_date,
        slot_time=slot_time,
        status='Scheduled'
    ).count()

    if overlap_count >= 3:
        flash("This time slot is fully booked. Please select a different time or date.", "danger")
        return redirect(url_for('dashboard_patient'))

    # 1. Execute AI Triage Engine
    triage = analyze_symptoms(symptoms, patient.age, patient.medical_history)
    
    # Find matching doctor profile details
    doctor = DoctorProfile.query.get(doctor_id)
    
    # 2. Estimate waiting time based on active department queue size
    dept = doctor.department
    current_waiting_count = Queue.query.filter_by(department=dept, status='Waiting').count()
    estimated_wait = calculate_estimated_wait(current_waiting_count, triage['priority_score'], triage['base_wait_time'])

    # Create Appointment
    appointment = Appointment(
        patient_id=patient.id,
        doctor_id=doctor.id,
        appointment_date=appt_date,
        slot_time=slot_time,
        symptoms=symptoms,
        triage_urgency=triage['urgency'],
        triage_score=triage['priority_score'],
        waiting_time_est=estimated_wait
    )
    db.session.add(appointment)
    db.session.flush() # get appointment id

    # 3. Smart Token Generation
    dept_prefix = dept[:3].upper() # e.g. CAR for Cardiology
    total_dept_tokens = Queue.query.filter_by(department=dept).count()
    token = f"{dept_prefix}-{total_dept_tokens + 1:03d}"

    # Push to Queue
    queue_entry = Queue(
        department=dept,
        appointment_id=appointment.id,
        token_number=token,
        priority_score=triage['priority_score'],
        estimated_wait_time=estimated_wait,
        status='Waiting'
    )
    db.session.add(queue_entry)

    # 4. Trigger simulated SMS/Email Notifications & Alerts
    alert_msg = f"Booking confirmed. Token: {token}. Dept: {dept}. Est Wait: {estimated_wait} mins. Urgency: {triage['urgency']}."
    if triage['urgency'] == 'Critical':
        alert_msg = f"🚨 EMERGENCY CRITICAL ALERT: Patient {current_user.name} flagged with Critical symptoms. Token {token} fast-tracked."
        # Broadcast Critical notification to doctors and nurses
        all_staff = User.query.filter(User.role.in_(['doctor', 'nurse', 'admin'])).all()
        for staff in all_staff:
            noti = Notification(user_id=staff.id, message=alert_msg)
            db.session.add(noti)
    else:
        # Patient specific notification
        noti = Notification(user_id=current_user.id, message=alert_msg)
        db.session.add(noti)
        # Doctor notification
        doc_noti = Notification(user_id=doctor.user_id, message=f"New Patient booked. Token {token}. Urgency: {triage['urgency']}.")
        db.session.add(doc_noti)

    db.session.commit()
    flash(f"Appointment booked! Token generated: {token}. Estimated wait: {estimated_wait} mins.", "success")
    return redirect(url_for('dashboard_patient'))


@app.route('/cancel-appointment/<int:appt_id>', methods=['POST'])
@login_required
def cancel_appointment(appt_id):
    appointment = Appointment.query.get_or_404(appt_id)
    
    # Permission verification
    if current_user.role == 'patient' and appointment.patient_id != current_user.patient_profile.id:
        flash("Unauthorized action.", "danger")
        return redirect(url_for('dashboard_patient'))
        
    appointment.status = 'Cancelled'
    if appointment.queue_entry:
        appointment.queue_entry.status = 'Cancelled'

    # Notification
    noti = Notification(user_id=appointment.patient.user_id, message=f"Appointment on {appointment.appointment_date} has been cancelled.")
    db.session.add(noti)

    db.session.commit()
    flash("Appointment has been cancelled successfully.", "success")
    return redirect(request.referrer or url_for('index'))


# --- Doctor Portal Operations ---

@app.route('/doctor/serve-patient/<int:queue_id>', methods=['POST'])
@login_required
def serve_patient(queue_id):
    if current_user.role != 'doctor':
        return redirect(url_for('index'))
        
    queue_entry = Queue.query.get_or_404(queue_id)
    doctor = current_user.doctor_profile

    # Update doctor status to Busy
    doctor.availability_status = 'Busy'

    # Set queue entry status
    queue_entry.status = 'Serving'
    db.session.commit()
    
    flash(f"Now serving patient: {queue_entry.appointment.patient.user.name} ({queue_entry.token_number}).", "info")
    return redirect(url_for('dashboard_doctor'))


@app.route('/doctor/complete-visit/<int:queue_id>', methods=['POST'])
@login_required
def complete_visit(queue_id):
    if current_user.role != 'doctor':
        return redirect(url_for('index'))
        
    queue_entry = Queue.query.get_or_404(queue_id)
    doctor = current_user.doctor_profile
    appointment = queue_entry.appointment

    diagnosis = request.form.get('diagnosis')
    prescription = request.form.get('prescription')
    lab_reports = request.form.get('lab_reports')

    if not diagnosis or not prescription:
        flash("Diagnosis and Prescription are mandatory to complete a medical record.", "danger")
        return redirect(url_for('dashboard_doctor'))

    # Generate AI Medical Summary
    ai_summary = summarize_medical_record(diagnosis, prescription)

    # 1. Create Digital Medical Record
    med_record = MedicalRecord(
        patient_id=appointment.patient_id,
        doctor_id=doctor.id,
        diagnosis=diagnosis,
        prescription=prescription,
        lab_reports=lab_reports,
        summary=ai_summary
    )
    db.session.add(med_record)

    # 2. Update Appointment status
    appointment.status = 'Completed'
    queue_entry.status = 'Completed'
    
    # Free up Doctor
    doctor.availability_status = 'Available'

    # 3. Readmission Risk Prediction
    prev_visits_count = MedicalRecord.query.filter_by(patient_id=appointment.patient_id).count()
    readmit = predict_readmission_risk(diagnosis, prev_visits_count)
    
    # Store prediction details inside notification/notes to alert patient
    readmit_alert = f"Readmission Risk Assessment: {readmit['level']} ({readmit['percentage']}%). {readmit['advice']}"
    noti = Notification(user_id=appointment.patient.user_id, message=f"Visit completed by {current_user.name}. Summary: {ai_summary}. {readmit_alert}")
    db.session.add(noti)

    db.session.commit()
    flash(f"Record compiled and finalized for token {queue_entry.token_number}.", "success")
    return redirect(url_for('dashboard_doctor'))


# --- Nurse Portal Operations ---

@app.route('/nurse/allocate-bed', methods=['POST'])
@login_required
def allocate_bed():
    if current_user.role != 'nurse':
        return redirect(url_for('index'))

    bed_id = request.form.get('bed_id')
    patient_id = request.form.get('patient_id')

    if not bed_id or not patient_id:
        flash("Please select both a bed and a patient.", "danger")
        return redirect(url_for('dashboard_nurse'))

    bed = Bed.query.get(bed_id)
    patient = PatientProfile.query.get(patient_id)

    if bed.status == 'Occupied':
        flash("Selected bed is already occupied.", "danger")
        return redirect(url_for('dashboard_nurse'))

    bed.status = 'Occupied'
    bed.assigned_patient_id = patient.id
    bed.allocated_at = datetime.utcnow()

    # Notification
    noti = Notification(
        user_id=patient.user_id, 
        message=f"You have been allocated to bed {bed.bed_number} ({bed.ward_type} Ward)."
    )
    db.session.add(noti)

    db.session.commit()
    flash(f"Bed {bed.bed_number} successfully allocated to {patient.user.name}.", "success")
    return redirect(url_for('dashboard_nurse'))


@app.route('/nurse/release-bed/<int:bed_id>', methods=['POST'])
@login_required
def release_bed(bed_id):
    if current_user.role != 'nurse':
        return redirect(url_for('index'))

    bed = Bed.query.get_or_404(bed_id)
    if bed.status != 'Occupied':
        flash("Bed is not currently occupied.", "danger")
        return redirect(url_for('dashboard_nurse'))

    patient_user_id = bed.patient.user_id
    bed.status = 'Available'
    bed.assigned_patient_id = None
    bed.allocated_at = None

    noti = Notification(user_id=patient_user_id, message="You have been discharged/released from your allocated bed.")
    db.session.add(noti)

    db.session.commit()
    flash(f"Bed {bed.bed_number} is now vacant.", "success")
    return redirect(url_for('dashboard_nurse'))


@app.route('/nurse/update-resource', methods=['POST'])
@login_required
def update_resource():
    if current_user.role != 'nurse':
        return redirect(url_for('index'))

    resource_id = request.form.get('resource_id')
    available_qty = request.form.get('available_qty')

    if not resource_id or not available_qty:
        flash("Missing quantity parameters.", "danger")
        return redirect(url_for('dashboard_nurse'))

    resource = Resource.query.get(resource_id)
    try:
        qty = int(available_qty)
        if qty < 0 or qty > resource.total_qty:
            flash(f"Quantity must be between 0 and total ({resource.total_qty}).", "danger")
            return redirect(url_for('dashboard_nurse'))
        resource.available_qty = qty
        db.session.commit()
        flash(f"Resource {resource.name} inventory count updated.", "success")
    except ValueError:
        flash("Invalid quantity value.", "danger")

    return redirect(url_for('dashboard_nurse'))


@app.route('/nurse/complete-task/<int:task_id>', methods=['POST'])
@login_required
def complete_task(task_id):
    if current_user.role not in ['nurse', 'admin']:
        return redirect(url_for('index'))

    task = StaffTask.query.get_or_404(task_id)
    task.status = 'Completed'
    db.session.commit()
    
    flash("Staff task marked as completed.", "success")
    return redirect(request.referrer or url_for('index'))


# --- Admin Portal Queue Override Operations ---

@app.route('/admin/bypass-queue/<int:queue_id>', methods=['POST'])
@login_required
def bypass_queue(queue_id):
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    queue_entry = Queue.query.get_or_404(queue_id)
    queue_entry.status = 'Bypassed'
    queue_entry.estimated_wait_time = 0
    
    # Notification
    noti = Notification(
        user_id=queue_entry.appointment.patient.user_id, 
        message=f"Your token {queue_entry.token_number} was fast-tracked/bypassed by admin administration."
    )
    db.session.add(noti)

    db.session.commit()
    flash(f"Token {queue_entry.token_number} bypassed.", "success")
    return redirect(url_for('dashboard_admin'))


@app.route('/admin/assign-task', methods=['POST'])
@login_required
def assign_task():
    if current_user.role != 'admin':
        return redirect(url_for('index'))

    nurse_id = request.form.get('nurse_id')
    description = request.form.get('task_description')
    priority = request.form.get('priority')

    if not nurse_id or not description:
        flash("Please select a nurse and enter task description.", "danger")
        return redirect(url_for('dashboard_admin'))

    task = StaffTask(
        assigned_to_user_id=nurse_id,
        task_description=description,
        priority=priority,
        status='Pending'
    )
    db.session.add(task)
    db.session.commit()
    
    flash("Task successfully assigned.", "success")
    return redirect(url_for('dashboard_admin'))


# --- AI Chatbot Assistant JSON API ---

@app.route('/api/chatbot', methods=['POST'])
def chatbot_api():
    data = request.get_json() or {}
    message = data.get('message', '')
    
    # If user is authenticated patient, load details for customized triage context
    age = 30
    history = ""
    if current_user.is_authenticated and current_user.role == 'patient':
        age = current_user.patient_profile.age
        history = current_user.patient_profile.medical_history or ""

    response_data = get_chatbot_response(message, age, history)
    return jsonify(response_data)


# --- Live Queue JSON API Endpoint (For dynamic AJAX updates) ---

@app.route('/api/queue/<department>')
def queue_api(department):
    queue_entries = Queue.query.filter_by(department=department, status='Waiting').order_by(
        Queue.priority_score.desc(), Queue.created_at.asc()
    ).all()
    
    output = []
    for q in queue_entries:
        output.append({
            'token': q.token_number,
            'priority_score': q.priority_score,
            'estimated_wait': q.estimated_wait_time
        })
    return jsonify(output)


# --- Notification System JSON Endpoints ---

@app.route('/api/notifications/unread')
@login_required
def unread_notifications():
    notifications = Notification.query.filter_by(user_id=current_user.id, read_status=False).all()
    return jsonify([{
        'id': n.id,
        'message': n.message,
        'created_at': n.created_at.strftime('%Y-%m-%d %H:%M')
    } for n in notifications])


@app.route('/api/notifications/mark-read/<int:noti_id>', methods=['POST'])
@login_required
def mark_notification_read(noti_id):
    noti = Notification.query.get_or_404(noti_id)
    if noti.user_id != current_user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    noti.read_status = True
    db.session.commit()
    return jsonify({'status': 'success'})


# --- App Startup & DB Init ---

if __name__ == '__main__':
    with app.app_context():
        seed_database()
    app.run(debug=True, host='0.0.0.0', port=5000)
