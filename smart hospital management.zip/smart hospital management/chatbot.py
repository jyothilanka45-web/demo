import re
from triage_engine import analyze_symptoms

def get_chatbot_response(user_message, patient_age=30, patient_history=""):
    """
    NLP keyword chatbot assistant.
    Returns: { "response": str, "suggested_action": str or None, "department": str or None }
    """
    msg = user_message.lower().strip()
    
    # Greetings
    if re.search(r"\b(hi|hello|hey|greetings|morning|afternoon|evening)\b", msg):
        return {
            "response": "Hello! I am your AI Hospital Assistant. You can tell me your symptoms (e.g., 'I have a persistent headache' or 'chest pain'), ask about hospital departments, check visiting hours, or get help with scheduling appointments.",
            "suggested_action": None,
            "department": None
        }

    # Hospital Visiting Hours
    if re.search(r"\b(visiting|hours|time|timing|timings|open|close|schedule)\b", msg) and not re.search(r"\b(appointment|book)\b", msg):
        return {
            "response": "Our general OPD and outpatient departments operate Monday to Saturday from 9:00 AM to 6:00 PM. Patient visiting hours for general wards are daily from 10:00 AM to 12:00 PM and 4:00 PM to 7:00 PM. The Emergency Room and ICU are open 24/7.",
            "suggested_action": "View Hospital Information",
            "department": None
        }

    # Hospital Departments
    if re.search(r"\b(department|departments|specialty|specialties|wards|clinics)\b", msg):
        return {
            "response": "Smart Hospital has several specialized departments: \n1. General Medicine (flu, infection, routine health)\n2. Cardiology (heart health, high blood pressure, chest pain)\n3. Orthopedics (bone fractures, joint pain, muscle strain)\n4. Pediatrics (infant and child healthcare)\n5. Emergency Care (trauma, stroke, severe bleeding)",
            "suggested_action": "View Departments",
            "department": None
        }

    # Appointment Booking Help
    if re.search(r"\b(appointment|book|schedule|reserve|doctor|slot|booking)\b", msg):
        return {
            "response": "To book an appointment, please log in to your Patient Dashboard, navigate to 'Book Appointment', input your symptoms, and select your preferred slot. Our AI system will automatically estimate your waiting time and prioritize you in the department queue.",
            "suggested_action": "Book Appointment Link",
            "department": None
        }

    # Symptom matching
    # Check if the message contains symptom keywords
    symptom_keywords = [
        "pain", "cough", "fever", "breathing", "breath", "bleed", "injury", "fracture", "bone",
        "stomach", "vomit", "nausea", "rash", "cold", "flu", "sore", "headache", "migraine",
        "paralysis", "weakness", "dizzy", "responsive", "unconscious", "chills", "throat"
    ]
    
    has_symptoms = any(k in msg for k in symptom_keywords) or len(msg.split()) >= 3
    
    if has_symptoms:
        # Run symptoms through Triage Engine
        triage = analyze_symptoms(user_message, patient_age, patient_history)
        
        urgency = triage["urgency"]
        disease = triage["disease"]
        dept = triage["department"]
        wait = triage["base_wait_time"]
        score = triage["priority_score"]
        
        if urgency == "Critical":
            resp = (
                f"Warning: Based on your symptoms, our AI triage engine suspects a possible case of {disease}. "
                f"This is classified as a CRITICAL emergency with a priority score of {score}/100.\n\n"
                f"Action Required: Please proceed immediately to our Emergency Department or call an ambulance. "
                f"The estimated wait time for walk-in critical triage is under {wait} minutes."
            )
            action = "Emergency Department"
        elif urgency == "Moderate":
            resp = (
                f"Our AI system indicates that your symptoms point towards {disease}. "
                f"This is classified as a MODERATE urgency level (Priority Score: {score}/100).\n\n"
                f"We recommend booking a prioritized appointment in our {dept} department. "
                f"The expected wait time is approximately {wait} minutes."
            )
            action = "Book prioritize appointment"
        else:
            resp = (
                f"Your symptoms suggest a normal, non-emergency condition: {disease}. "
                f"This is classified as a NORMAL priority level (Priority Score: {score}/100).\n\n"
                f"You can schedule a standard appointment in our {dept} department. "
                f"The estimated wait time is {wait} minutes. Please get rest and stay hydrated."
            )
            action = "Book normal appointment"
            
        return {
            "response": resp,
            "suggested_action": action,
            "department": dept
        }

    # Default fallback response
    return {
        "response": "I didn't quite capture that. You can describe your symptoms (e.g., 'my knee hurts' or 'I have a high fever'), ask about departments, or inquire about visiting hours.",
        "suggested_action": None,
        "department": None
    }
