import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'hospital-management-secret-key-12345'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///hospital.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
