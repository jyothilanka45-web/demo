from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model, UserMixin):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'admin', 'doctor', 'nurse', 'patient'
    name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    patient_profile = db.relationship('PatientProfile', backref='user', uselist=False, cascade="all, delete-orphan")
    doctor_profile = db.relationship('DoctorProfile', backref='user', uselist=False, cascade="all, delete-orphan")
    tasks = db.relationship('StaffTask', backref='assigned_staff', lazy='dynamic')
    notifications = db.relationship('Notification', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class PatientProfile(db.Model):
    __tablename__ = 'patient_profiles'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    blood_group = db.Column(db.String(5), nullable=True)
    medical_history = db.Column(db.Text, nullable=True)  # Comma-separated or free text

    # Relationships
    appointments = db.relationship('Appointment', backref='patient', lazy='dynamic')
    medical_records = db.relationship('MedicalRecord', backref='patient', lazy='dynamic')
    beds = db.relationship('Bed', backref='patient', lazy='dynamic')


class DoctorProfile(db.Model):
    __tablename__ = 'doctor_profiles'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    department = db.Column(db.String(50), nullable=False)  # 'Cardiology', 'Pediatrics', 'Orthopedics', 'General Medicine', etc.
    specialization = db.Column(db.String(100), nullable=False)
    availability_status = db.Column(db.String(20), default='Available')  # 'Available', 'Busy', 'Off-Duty'
    room_no = db.Column(db.String(10), nullable=False)

    # Relationships
    appointments = db.relationship('Appointment', backref='doctor', lazy='dynamic')
    medical_records = db.relationship('MedicalRecord', backref='doctor', lazy='dynamic')


class Appointment(db.Model):
    __tablename__ = 'appointments'
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient_profiles.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor_profiles.id'), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    slot_time = db.Column(db.String(10), nullable=False)  # e.g., '09:00 AM'
    status = db.Column(db.String(20), default='Scheduled')  # 'Scheduled', 'Completed', 'Cancelled'
    symptoms = db.Column(db.Text, nullable=False)
    
    # Triage and Flow Optimization fields
    triage_urgency = db.Column(db.String(10), nullable=True)  # 'Critical', 'Moderate', 'Normal'
    triage_score = db.Column(db.Integer, nullable=True)  # 0 to 100
    waiting_time_est = db.Column(db.Integer, nullable=True)  # in minutes
    notes = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Queue connection
    queue_entry = db.relationship('Queue', backref='appointment', uselist=False, cascade="all, delete-orphan")


class Queue(db.Model):
    __tablename__ = 'queues'
    id = db.Column(db.Integer, primary_key=True)
    department = db.Column(db.String(50), nullable=False)
    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'), nullable=False)
    token_number = db.Column(db.String(20), nullable=False)  # e.g., 'GEN-01'
    priority_score = db.Column(db.Integer, nullable=False, default=0)  # higher = faster service
    status = db.Column(db.String(20), default='Waiting')  # 'Waiting', 'Serving', 'Completed', 'Bypassed'
    estimated_wait_time = db.Column(db.Integer, nullable=False)  # minutes
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MedicalRecord(db.Model):
    __tablename__ = 'medical_records'
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient_profiles.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor_profiles.id'), nullable=False)
    visit_date = db.Column(db.DateTime, default=datetime.utcnow)
    diagnosis = db.Column(db.Text, nullable=False)
    prescription = db.Column(db.Text, nullable=False)
    lab_reports = db.Column(db.Text, nullable=True)
    summary = db.Column(db.Text, nullable=True)  # AI Generated summary


class Bed(db.Model):
    __tablename__ = 'beds'
    id = db.Column(db.Integer, primary_key=True)
    bed_number = db.Column(db.String(10), unique=True, nullable=False)
    ward_type = db.Column(db.String(20), nullable=False)  # 'General', 'ICU', 'Semi-Private'
    status = db.Column(db.String(20), default='Available')  # 'Available', 'Occupied', 'Maintenance'
    assigned_patient_id = db.Column(db.Integer, db.ForeignKey('patient_profiles.id'), nullable=True)
    allocated_at = db.Column(db.DateTime, nullable=True)


class Resource(db.Model):
    __tablename__ = 'resources'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)  # e.g., 'Ventilator', 'ECG Monitor'
    total_qty = db.Column(db.Integer, nullable=False)
    available_qty = db.Column(db.Integer, nullable=False)
    location = db.Column(db.String(50), nullable=False)  # e.g., 'ICU Wing A', 'General Ward'


class StaffTask(db.Model):
    __tablename__ = 'staff_tasks'
    id = db.Column(db.Integer, primary_key=True)
    assigned_to_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    task_description = db.Column(db.Text, nullable=False)
    priority = db.Column(db.String(10), default='Medium')  # 'High', 'Medium', 'Low'
    status = db.Column(db.String(20), default='Pending')  # 'Pending', 'In Progress', 'Completed'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    __tablename__ = 'notifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    read_status = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
