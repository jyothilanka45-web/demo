// Main JavaScript operations for Smart Hospital Management System

document.addEventListener("DOMContentLoaded", function () {
    // Initialize tooltips/popovers if needed
    
    // --- Chatbot Functionality ---
    const chatForm = document.getElementById("chatbot-form");
    const chatInput = document.getElementById("chatbot-input");
    const chatMessages = document.getElementById("chatbot-messages");

    if (chatForm && chatInput && chatMessages) {
        chatForm.addEventListener("submit", function (e) {
            e.preventDefault();
            const message = chatInput.value.trim();
            if (!message) return;

            // Append User message
            appendMessage("user", message);
            chatInput.value = "";

            // Send to server
            fetch("/api/chatbot", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ message: message })
            })
            .then(res => res.json())
            .then(data => {
                appendMessage("bot", data.response);
                if (data.suggested_action) {
                    appendSystemAction(data.suggested_action, data.department);
                }
            })
            .catch(err => {
                console.error("Chat error:", err);
                appendMessage("bot", "Sorry, I am having trouble connecting to the hospital database right now.");
            });
        });

        function appendMessage(sender, text) {
            const bubble = document.createElement("div");
            bubble.classList.add("chat-bubble", sender);
            bubble.innerText = text;
            chatMessages.appendChild(bubble);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function appendSystemAction(actionText, department) {
            const container = document.createElement("div");
            container.classList.add("d-flex", "justify-content-center", "mb-3");
            const btn = document.createElement("button");
            btn.classList.add("btn", "btn-sm", "btn-outline-info");
            btn.innerText = `Shortcut: ${actionText}`;
            btn.addEventListener("click", () => {
                if (department) {
                    const deptSelect = document.getElementById("dept-selector-dropdown");
                    if (deptSelect) {
                        deptSelect.value = department;
                        deptSelect.dispatchEvent(new Event('change'));
                    }
                }
                // Scroll to book form
                const bookForm = document.getElementById("booking-card-section");
                if (bookForm) {
                    bookForm.scrollIntoView({ behavior: 'smooth' });
                }
            });
            container.appendChild(btn);
            chatMessages.appendChild(container);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    // --- Dynamic Department Queue Refresh ---
    const deptSelect = document.getElementById("queue-dept-select");
    const queueTableBody = document.getElementById("queue-table-body");

    if (deptSelect && queueTableBody) {
        function refreshQueue() {
            const dept = deptSelect.value;
            if (!dept) {
                queueTableBody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">Select a department to view queue status</td></tr>';
                return;
            }

            fetch(`/api/queue/${encodeURIComponent(dept)}`)
                .then(res => res.json())
                .then(data => {
                    queueTableBody.innerHTML = "";
                    if (data.length === 0) {
                        queueTableBody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No patient in queue</td></tr>';
                        return;
                    }

                    data.forEach((item, index) => {
                        const tr = document.createElement("tr");
                        tr.innerHTML = `
                            <td><strong>${item.token}</strong></td>
                            <td>${item.priority_score}</td>
                            <td>${item.estimated_wait} mins</td>
                        `;
                        // Highlight first token (currently serving/next)
                        if (index === 0) {
                            tr.classList.add("table-active");
                        }
                        queueTableBody.appendChild(tr);
                    });
                })
                .catch(err => {
                    console.error("Queue fetch error:", err);
                });
        }

        deptSelect.addEventListener("change", refreshQueue);
        
        // Initial load
        refreshQueue();
        
        // Auto-refresh queue every 15 seconds
        setInterval(refreshQueue, 15000);
    }

    // --- Notification System polling & Actions ---
    const notiList = document.getElementById("notification-dropdown-list");
    const notiBadge = document.getElementById("notification-unread-count");

    if (notiList && notiBadge) {
        function checkNotifications() {
            fetch("/api/notifications/unread")
                .then(res => res.json())
                .then(data => {
                    if (data.length > 0) {
                        notiBadge.style.display = "inline-block";
                        notiBadge.innerText = data.length;
                        notiList.innerHTML = "";
                        
                        data.forEach(n => {
                            const li = document.createElement("li");
                            li.innerHTML = `
                                <div class="dropdown-item d-flex justify-content-between align-items-start border-bottom py-2">
                                    <div class="me-3">
                                        <p class="mb-0 text-wrap font-size-sm" style="max-width: 220px; font-size:0.85rem;">${n.message}</p>
                                        <small class="text-muted" style="font-size:0.75rem;">${n.created_at}</small>
                                    </div>
                                    <button class="btn btn-sm text-info mark-read-btn" data-id="${n.id}">Mark read</button>
                                </div>
                            `;
                            notiList.appendChild(li);
                        });

                        // Attach event listeners
                        document.querySelectorAll(".mark-read-btn").forEach(btn => {
                            btn.addEventListener("click", function(e) {
                                e.preventDefault();
                                e.stopPropagation();
                                const id = this.getAttribute("data-id");
                                fetch(`/api/notifications/mark-read/${id}`, { method: "POST" })
                                    .then(() => checkNotifications());
                            });
                        });
                    } else {
                        notiBadge.style.display = "none";
                        notiList.innerHTML = '<li><div class="dropdown-item text-center text-muted py-2" style="font-size:0.85rem;">No new notifications</div></li>';
                    }
                })
                .catch(err => console.error("Notification check error:", err));
        }

        // Initial check and set interval (30 seconds)
        checkNotifications();
        setInterval(checkNotifications, 30000);
    }
});

// --- Dynamic Charts Initializer for Admin Dashboard ---
function initAdminCharts(analytics) {
    // 1. Patient Daily Chart
    const patientCtx = document.getElementById("dailyPatientsChart");
    if (patientCtx) {
        const labels = analytics.daily_patients.map(d => d.day);
        const data = analytics.daily_patients.map(d => d.count);
        new Chart(patientCtx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Daily Appointments',
                    data: data,
                    borderColor: '#0ea5e9',
                    backgroundColor: 'rgba(14, 165, 233, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1, color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.05)' }
                    },
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { display: false }
                    }
                }
            }
        });
    }

    // 2. Urgency Case distribution
    const urgencyCtx = document.getElementById("urgencyChart");
    if (urgencyCtx) {
        const labels = analytics.urgency_distribution.map(u => u.urgency);
        const data = analytics.urgency_distribution.map(u => u.count);
        new Chart(urgencyCtx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: [
                        '#ef4444', // Critical
                        '#f97316', // Moderate
                        '#10b981'  // Normal
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#9ca3af', boxWidth: 12 }
                    }
                }
            }
        });
    }

    // 3. Department waiting times
    const waitCtx = document.getElementById("waitTimeChart");
    if (waitCtx) {
        const labels = analytics.department_waiting_time.map(w => w.department);
        const data = analytics.department_waiting_time.map(w => w.avg_wait);
        new Chart(waitCtx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: '#06b6d4'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { color: '#9ca3af' },
                        grid: { color: 'rgba(255,255,255,0.05)' }
                    },
                    x: {
                        ticks: { color: '#9ca3af' },
                        grid: { display: false }
                    }
                }
            }
        });
    }
}
