import unittest
from datetime import datetime, date
from app import app, db
from models import User, PatientProfile, DoctorProfile, Appointment, Queue, MedicalRecord
from triage_engine import analyze_symptoms, calculate_estimated_wait

class SmartHospitalTestCase(unittest.TestCase):
    def setUp(self):
        # Configure app for testing
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['WTF_CSRF_ENABLED'] = False
        self.app = app.test_client()
        
        # Create database and seed
        with app.app_context():
            db.create_all()
            self.seed_test_data()

    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def seed_test_data(self):
        # Seed a doctor
        u = User(username='dr_test', email='dr.test@smarthospital.com', role='doctor', name='Dr. Test General')
        u.set_password('doctor123')
        db.session.add(u)
        db.session.flush()
        
        dp = DoctorProfile(user_id=u.id, department='General Medicine', specialization='Testing Spec', room_no='Room 99')
        db.session.add(dp)
        
        db.session.commit()

    def test_user_registration(self):
        """Test registration of a new patient user."""
        response = self.app.post('/register', data={
            'username': 'patient_test',
            'email': 'patient.test@test.com',
            'password': 'patient123',
            'name': 'Patient Test',
            'phone': '1234567890',
            'age': '28',
            'gender': 'Male',
            'blood_group': 'O+',
            'medical_history': 'None'
        }, follow_redirects=True)
        
        self.assertEqual(response.status_code, 200)
        
        with app.app_context():
            user = User.query.filter_by(username='patient_test').first()
            self.assertIsNotNone(user)
            self.assertEqual(user.role, 'patient')
            self.assertEqual(user.patient_profile.age, 28)

    def test_ai_triage_engine_rules(self):
        """Verify AI symptoms assessment engine returns appropriate urgency levels."""
        # 1. Critical Symptoms check
        result_critical = analyze_symptoms("I have severe chest pain and left arm numbness.", age=65, medical_history="Hypertension")
        self.assertEqual(result_critical['urgency'], 'Critical')
        self.assertEqual(result_critical['department'], 'Cardiology')
        self.assertTrue(result_critical['priority_score'] >= 90)

        # 2. Moderate Symptoms check
        result_mod = analyze_symptoms("I fell down and think my arm is fractured.", age=30)
        self.assertEqual(result_mod['urgency'], 'Moderate')
        self.assertEqual(result_mod['department'], 'Orthopedics')

        # 3. Normal Symptoms check
        result_norm = analyze_symptoms("I have a runny nose and mild cold.", age=25)
        self.assertEqual(result_norm['urgency'], 'Normal')
        self.assertEqual(result_norm['department'], 'General Medicine')

    def test_queue_sorting_prioritization(self):
        """Verify queue logic fast-tracks critical patients before normal ones."""
        with app.app_context():
            # Setup a doctor
            doc = DoctorProfile.query.first()
            
            # Setup two patients
            u_norm = User(username='p_norm', email='p_norm@test.com', role='patient', name='Patient Normal')
            u_norm.set_password('pat123')
            db.session.add(u_norm)
            
            u_crit = User(username='p_crit', email='p_crit@test.com', role='patient', name='Patient Critical')
            u_crit.set_password('pat123')
            db.session.add(u_crit)
            db.session.flush()

            p_norm = PatientProfile(user_id=u_norm.id, age=30, gender='Female')
            p_crit = PatientProfile(user_id=u_crit.id, age=70, gender='Male', medical_history='Hypertension')
            db.session.add(p_norm)
            db.session.add(p_crit)
            db.session.flush()

            # Book normal patient first
            appt_norm = Appointment(
                patient_id=p_norm.id, doctor_id=doc.id, appointment_date=date.today(), slot_time='09:00 AM',
                symptoms='Mild cough', triage_urgency='Normal', triage_score=20, waiting_time_est=60
            )
            db.session.add(appt_norm)
            db.session.flush()

            q_norm = Queue(
                department='General Medicine', appointment_id=appt_norm.id, token_number='GEN-001',
                priority_score=20, estimated_wait_time=60, status='Waiting'
            )
            db.session.add(q_norm)

            # Book critical patient second
            appt_crit = Appointment(
                patient_id=p_crit.id, doctor_id=doc.id, appointment_date=date.today(), slot_time='09:00 AM',
                symptoms='Severe chest pain', triage_urgency='Critical', triage_score=95, waiting_time_est=10
            )
            db.session.add(appt_crit)
            db.session.flush()

            q_crit = Queue(
                department='General Medicine', appointment_id=appt_crit.id, token_number='GEN-002',
                priority_score=95, estimated_wait_time=10, status='Waiting'
            )
            db.session.add(q_crit)
            db.session.commit()

            # Query waiting queue ordered by score (desc) and time (asc)
            ordered_queue = Queue.query.filter_by(department='General Medicine', status='Waiting').order_by(
                Queue.priority_score.desc(), Queue.created_at.asc()
            ).all()

            # Critical patient must be first in list despite booking second
            self.assertEqual(len(ordered_queue), 2)
            self.assertEqual(ordered_queue[0].token_number, 'GEN-002')  # Critical token
            self.assertEqual(ordered_queue[1].token_number, 'GEN-001')  # Normal token

    def test_chatbot_api(self):
        """Test chatbot response format and symptom triage integration."""
        response = self.app.post('/api/chatbot', json={'message': 'I have chest pain'})
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertIn('response', data)
        self.assertIn('suggested_action', data)
        self.assertEqual(data['department'], 'Cardiology')

if __name__ == '__main__':
    unittest.main()
