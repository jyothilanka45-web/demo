import re
from datetime import datetime, timedelta

# Symptom to Disease mapping rules
SYMPTOM_RULES = [
    {
        "keywords": [r"\bchest\s*pain\b", r"\bangina\b", r"\bheart\s*attack\b", r"\bcardiac\b", r"\bleft\s*arm\s*pain\b"],
        "disease": "Acute Coronary Syndrome (Suspected Heart Attack)",
        "department": "Cardiology",
        "urgency": "Critical",
        "base_score": 90,
        "base_wait": 10
    },
    {
        "keywords": [r"\bstroke\b", r"\bparalysis\b", r"\bslurred\s*speech\b", r"\bnumbness\b", r"\bweakness\s*one\s*side\b"],
        "disease": "Acute Cerebrovascular Event (Suspected Stroke)",
        "department": "General Medicine",
        "urgency": "Critical",
        "base_score": 95,
        "base_wait": 5
    },
    {
        "keywords": [r"\bdifficulty\s*breathing\b", r"\bshortness\s*of\s*breath\b", r"\basthma\s*attack\b", r"\bwheezing\b", r"\bsuffocation\b"],
        "disease": "Acute Respiratory Distress / Severe Asthma",
        "department": "General Medicine",
        "urgency": "Critical",
        "base_score": 85,
        "base_wait": 10
    },
    {
        "keywords": [r"\bsevere\s*bleeding\b", r"\bhemorrhage\b", r"\bdeep\s*cut\b", r"\bgunshot\b", r"\bstab\b"],
        "disease": "Severe Hemorrhage / Acute Trauma",
        "department": "General Medicine",
        "urgency": "Critical",
        "base_score": 90,
        "base_wait": 8
    },
    {
        "keywords": [r"\bunconscious\b", r"\bfainted\b", r"\bresponsive\b", r"\bcoma\b"],
        "disease": "Loss of Consciousness (Unresponsive)",
        "department": "General Medicine",
        "urgency": "Critical",
        "base_score": 95,
        "base_wait": 5
    },
    {
        "keywords": [r"\bhigh\s*fever\b", r"\bchills\b", r"\bpneumonia\b", r"\bsevere\s*cough\b", r"\bbronchitis\b"],
        "disease": "Severe Respiratory Infection / Suspected Pneumonia",
        "department": "General Medicine",
        "urgency": "Moderate",
        "base_score": 60,
        "base_wait": 30
    },
    {
        "keywords": [r"\bfractur\w*", r"\bbroken\s*bone\b", r"\bdislocation\b", r"\bsevere\s*sprain\b", r"\bunable\s*to\s*walk\b"],
        "disease": "Skeletal Trauma (Suspected Fracture)",
        "department": "Orthopedics",
        "urgency": "Moderate",
        "base_score": 55,
        "base_wait": 40
    },
    {
        "keywords": [r"\bchild\s*fever\b", r"\bpediatric\b", r"\bbaby\s*vomiting\b", r"\bchild\s*cough\b"],
        "disease": "Pediatric Viral / Inflammatory Condition",
        "department": "Pediatrics",
        "urgency": "Moderate",
        "base_score": 50,
        "base_wait": 30
    },
    {
        "keywords": [r"\bcold\b", r"\bflu\b", r"\bmild\s*fever\b", r"\brunny\s*nose\b", r"\bsore\s*throat\b", r"\bmild\s*cough\b"],
        "disease": "Upper Respiratory Tract Infection (Common Cold / Flu)",
        "department": "General Medicine",
        "urgency": "Normal",
        "base_score": 20,
        "base_wait": 60
    },
    {
        "keywords": [r"\bheadache\b", r"\bmigraine\b", r"\bdizzy\b"],
        "disease": "Migraine / Tension Headache",
        "department": "General Medicine",
        "urgency": "Normal",
        "base_score": 25,
        "base_wait": 45
    },
    {
        "keywords": [r"\bstomach\s*pain\b", r"\bnausea\b", r"\bvomiting\b", r"\bdiarrhea\b", r"\bgastric\b", r"\bacidity\b"],
        "disease": "Acute Gastroenteritis / Acid Dyspepsia",
        "department": "General Medicine",
        "urgency": "Normal",
        "base_score": 25,
        "base_wait": 50
    },
    {
        "keywords": [r"\bjoint\s*pain\b", r"\bback\s*pain\b", r"\barthritis\b", r"\bmuscle\s*ache\b"],
        "disease": "Chronic Musculoskeletal Pain / Arthritis",
        "department": "Orthopedics",
        "urgency": "Normal",
        "base_score": 20,
        "base_wait": 60
    },
    {
        "keywords": [r"\brash\b", r"\bitchy\b", r"\ballergy\b", r"\bskin\s*infection\b", r"\beczema\b"],
        "disease": "Contact Dermatitis / Allergic Skin Reaction",
        "department": "General Medicine",
        "urgency": "Normal",
        "base_score": 15,
        "base_wait": 65
    }
]

def analyze_symptoms(symptoms_text, age, medical_history=""):
    """
    Parses symptom text and returns:
    predicted_disease, department, urgency_level, priority_score, base_wait_time
    """
    text_lower = symptoms_text.lower()
    history_lower = (medical_history or "").lower()

    matched_rule = None
    for rule in SYMPTOM_RULES:
        for pattern in rule["keywords"]:
            if re.search(pattern, text_lower):
                matched_rule = rule
                break
        if matched_rule:
            break

    if not matched_rule:
        # Fallback default rule
        matched_rule = {
            "disease": "General Health Symptoms (Undifferentiated)",
            "department": "General Medicine",
            "urgency": "Normal",
            "base_score": 15,
            "base_wait": 60
        }

    disease = matched_rule["disease"]
    department = matched_rule["department"]
    urgency = matched_rule["urgency"]
    base_score = matched_rule["base_score"]
    base_wait = matched_rule["base_wait"]

    # Calculate Priority Modifier
    priority_score = base_score

    # Age buffers
    if age >= 65:
        priority_score += 10
    elif age <= 5:
        priority_score += 10

    # Comorbidities indicators
    comorbidities = ["hypertension", "diabetes", "heart", "asthma", "copd", "kidney", "cancer"]
    history_multiplier = 0
    for cond in comorbidities:
        if cond in history_lower:
            history_multiplier += 5
    
    priority_score += history_multiplier

    # Cap priority score
    priority_score = min(max(priority_score, 0), 100)

    return {
        "disease": disease,
        "department": department,
        "urgency": urgency,
        "priority_score": priority_score,
        "base_wait_time": base_wait
    }

def calculate_estimated_wait(queue_length, priority_score, base_wait):
    """
    Dynamically adjusts wait times based on department queue length and priority score.
    """
    # Wait is shorter for higher priority, longer for longer queues
    wait_time = base_wait + (queue_length * 10)
    # Priority reduction
    wait_reduction = int(priority_score * 0.4)
    wait_time = max(wait_time - wait_reduction, 5) # Minimum 5 minutes
    return wait_time

def predict_disease_risks(age, gender, medical_history):
    """
    Returns disease risk predictions based on patient metrics.
    """
    history_lower = (medical_history or "").lower()
    risks = []

    # Cardiovascular Risk
    cv_score = 0
    if age >= 50: cv_score += 25
    if "hypertension" in history_lower or "high blood pressure" in history_lower: cv_score += 40
    if "diabetes" in history_lower: cv_score += 20
    if "cholesterol" in history_lower: cv_score += 15
    if cv_score >= 50:
        risks.append({"disease": "Cardiovascular Disease", "risk": "High", "percentage": cv_score, "description": "Elevated risk due to age and history of hypertension/diabetes."})
    elif cv_score >= 20:
        risks.append({"disease": "Cardiovascular Disease", "risk": "Moderate", "percentage": cv_score, "description": "Moderate risk. Lifestyle changes and blood pressure monitoring recommended."})
    else:
        risks.append({"disease": "Cardiovascular Disease", "risk": "Low", "percentage": max(cv_score, 5), "description": "Risk parameters are within normal ranges."})

    # Type 2 Diabetes Risk
    db_score = 0
    if age >= 45: db_score += 20
    if "obesity" in history_lower or "overweight" in history_lower: db_score += 30
    if "hypertension" in history_lower: db_score += 20
    if "thyroid" in history_lower: db_score += 10
    if "diabetes" in history_lower:
        risks.append({"disease": "Type 2 Diabetes", "risk": "Diagnosed", "percentage": 100, "description": "Patient has pre-existing diagnosed Type 2 Diabetes."})
    else:
        if db_score >= 50:
            risks.append({"disease": "Type 2 Diabetes", "risk": "High", "percentage": db_score, "description": "High risk of insulin resistance. Glucose tolerance test advised."})
        elif db_score >= 20:
            risks.append({"disease": "Type 2 Diabetes", "risk": "Moderate", "percentage": db_score, "description": "Moderate risk. Maintain a balanced diet and active lifestyle."})
        else:
            risks.append({"disease": "Type 2 Diabetes", "risk": "Low", "percentage": max(db_score, 5), "description": "Risk profile indicates low immediate threat."})

    # Chronic Kidney Disease Risk
    kd_score = 0
    if "diabetes" in history_lower: kd_score += 35
    if "hypertension" in history_lower: kd_score += 25
    if age >= 60: kd_score += 15
    if kd_score >= 40:
        risks.append({"disease": "Chronic Kidney Disease", "risk": "Moderate", "percentage": kd_score, "description": "Moderate risk related to cardiovascular or diabetic indicators."})
    elif kd_score >= 10:
        risks.append({"disease": "Chronic Kidney Disease", "risk": "Low", "percentage": kd_score, "description": "Routine renal function parameters appear stable."})

    return risks

def predict_readmission_risk(diagnosis, previous_visits_count):
    """
    Estimate readmission probability based on previous visit history and diagnosis severity.
    """
    severity_factor = 10
    diag_lower = diagnosis.lower()
    
    # Check severity keywords
    if any(k in diag_lower for k in ["critical", "heart", "stroke", "chronic", "failure", "unconscious", "kidney"]):
        severity_factor = 35

    # Linear increase with previous visits
    visit_factor = min(previous_visits_count * 12, 50)
    
    total_risk = severity_factor + visit_factor
    total_risk = min(max(total_risk, 5), 90)

    if total_risk >= 60:
        risk_level = "High"
        advice = "High readmission danger. Set follow-up within 7 days, optimize medicines, and track vitals."
    elif total_risk >= 30:
        risk_level = "Moderate"
        advice = "Moderate risk. Ensure full prescription compliance and schedule standard 2-week checkup."
    else:
        risk_level = "Low"
        advice = "Standard discharge protocols. Standard follow-up appointments apply."

    return {
        "percentage": total_risk,
        "level": risk_level,
        "advice": advice
    }

def summarize_medical_record(diagnosis, prescription):
    """
    Extractive summarization generator compiling diagnosis and prescription notes.
    """
    if not diagnosis or not prescription:
        return "No sufficient clinical information to compile a digital summary."

    diag_sentence = diagnosis.strip().split('.')[0]
    rx_items = [item.strip() for item in prescription.split('\n') if item.strip()][:2]
    rx_summary = ", ".join(rx_items) if rx_items else "supportive therapy"

    summary = f"Patient diagnosed with {diag_sentence}. Prescribed course includes: {rx_summary}. Advised follow-up if symptoms persist."
    return summary

def predict_hospital_demand(appointment_counts):
    """
    Expects dictionary of {date_string: count} for the last 7 days.
    Returns next 7 days forecast using simple moving average and day-of-week weights.
    """
    # Fallback default historical counts if data is empty
    if not appointment_counts:
        appointment_counts = {
            (datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d'): 5 + (i % 3)
            for i in range(7)
        }

    # Extract counts
    counts = list(appointment_counts.values())
    avg_load = sum(counts) / len(counts) if counts else 10.0

    forecast = []
    base_date = datetime.now()
    
    # Predict next 7 days
    for i in range(1, 8):
        forecast_date = base_date + timedelta(days=i)
        
        # Day weight simulation (Mondays and Fridays are busier)
        day_weight = 1.2 if forecast_date.weekday() in [0, 4] else (0.8 if forecast_date.weekday() == 6 else 1.0)
        predicted_count = int(avg_load * day_weight + (i % 2))
        
        # Resource requirement calculations
        predicted_beds = max(int(predicted_count * 0.3), 1)
        predicted_icu = max(int(predicted_count * 0.1), 0)
        ventilator_need = max(int(predicted_icu * 0.5), 0)

        forecast.append({
            "date": forecast_date.strftime('%Y-%m-%d'),
            "day": forecast_date.strftime('%A'),
            "expected_patients": predicted_count,
            "required_beds": predicted_beds,
            "required_icu": predicted_icu,
            "ventilators_demand": ventilator_need
        })

    return forecast
